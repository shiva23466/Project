let isFollowing = false;   
let followersCount = 0;       

const profile = [
    {
        name: "Sarah Jensen",
        username: "@sarah_j"
    }
];

function toggleFollow() {

    const btn = document.getElementById("followBtn");
    const status = document.getElementById("status");

    if (isFollowing === false) {

        isFollowing = true;
        followersCount++; // Increment Operator

        btn.innerText = "Following";
        btn.classList.add("following");

        status.innerText =
            `Following | Count: ${followersCount}`;

    } else {

        isFollowing = false;
        followersCount--;

        btn.innerText = "Follow";
        btn.classList.remove("following");

        status.innerText =
            `Not Following | Count: ${followersCount}`;
    }

    console.log(profile);
}