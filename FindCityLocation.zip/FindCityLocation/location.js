const apiKey = "0b420a0e60cd4909ef3a850cce463ca4";

const cityInput = document.getElementById("city");
const searchBtn = document.getElementById("searchBtn");
const result = document.getElementById("result");

searchBtn.addEventListener("click", getLocation);

cityInput.addEventListener("keypress", function (e) {
    if (e.key === "Enter") {
        getLocation();
    }
});

async function getLocation() {
    const city = cityInput.value.trim();

    if (city === "") {
        result.innerHTML = `<p class="error">Please enter a city name.</p>`;
        return;
    }

    const url = `https://api.openweathermap.org/geo/1.0/direct?q=${encodeURIComponent(city)}&limit=1&appid=${apiKey}`;

    try {
        const response = await fetch(url);

        if (!response.ok) {
            throw new Error(`HTTP Error: ${response.status}`);
        }

        const data = await response.json();

        if (data.length === 0) {
            result.innerHTML = `<p class="error">City not found.</p>`;
            return;
        }

        const location = data[0];

        result.innerHTML = `
            <div class="card">
                <h2>📍 ${location.name}</h2>
                <p><strong>Country:</strong> ${location.country}</p>
                <p><strong>State:</strong> ${location.state || "N/A"}</p>
                <p><strong>Latitude:</strong> ${location.lat}</p>
                <p><strong>Longitude:</strong> ${location.lon}</p>

                <a href="https://www.google.com/maps?q=${location.lat},${location.lon}" target="_blank">
                    🌍 View on Google Maps
                </a>
            </div>
        `;
    } catch (error) {
        console.error(error);

        result.innerHTML = `
            <p class="error">
                Something went wrong.<br>
                ${error.message}
            </p>
        `;
    }
}