// ================================QUIZ QUESTIONS==============================

let questions = [
{
question: "Which company developed JavaScript?",
options: ["Microsoft", "Google", "Netscape", "Oracle"],
answer: "Netscape"
},
{
question: "Which keyword is used to declare a variable?",
options: ["variable", "var", "constant", "define"],
answer: "var"
},
{
question: "Which symbol is used for comments in JavaScript?",
options: ["//", "<!-- -->", "**", "##"],
answer: "//"
},
{
question: "Which method converts JSON into JavaScript object?",
options: [
"JSON.stringify()",
"JSON.parse()",
"JSON.convert()",
"JSON.object()"
],
answer: "JSON.parse()"
},
{
question: "Which keyword creates a constant?",
options: ["const", "constant", "fixed", "let"],
answer: "const"
},
{
question: "What is the output type of typeof [] ?",
options: ["Array", "Object", "List", "Undefined"],
answer: "Object"
},
{
question: "Which operator checks both value and datatype?",
options: ["==", "=", "===", "!="],
answer: "==="
},
{
question: "Which loop executes at least once?",
options: [
"for",
"while",
"do...while",
"foreach"
],
answer: "do...while"
},
{
question: "Which method adds an element to end of array?",
options: [
"push()",
"pop()",
"shift()",
"unshift()"
],
answer: "push()"
},
{
question: "DOM stands for?",
options: [
"Document Object Model",
"Data Object Management",
"Desktop Object Model",
"Document Oriented Model"
],
answer: "Document Object Model"
}
];

// ==================================== RANDOMIZE QUESTIONS ================================

questions.sort(() => Math.random() - 0.5);

questions.forEach(q => {
q.options.sort(() => Math.random() - 0.5);
});

// ==================================== DOM ELEMENTS ========================================

const welcomeScreen = document.getElementById("welcome-screen");
const quizScreen = document.getElementById("quiz-screen");
const resultScreen = document.getElementById("result-screen");
const startBtn = document.getElementById("start-btn");
const nextBtn = document.getElementById("next-btn");
const prevBtn = document.getElementById("prev-btn");
const submitBtn = document.getElementById("submit-btn");
const restartBtn = document.getElementById("restart-btn");
const question = document.getElementById("question");
const options = document.getElementById("options");
const questionCount = document.getElementById("question-count");
const progressBar = document.getElementById("progress-bar");
const timer = document.getElementById("timer");

// Result Elements

const score = document.getElementById("score");
const correct = document.getElementById("correct");
const wrong = document.getElementById("wrong");
const percentage = document.getElementById("percentage");
const message = document.getElementById("message");
const highScore = document.getElementById("high-score");

// ===================================  VARIABLES  ===================================

let currentQuestion = 0;
let answers = new Array(questions.length).fill(null);
let scoreCount = 0;
let timeLeft = 20;
let timerInterval;

// ====================================   START QUIZ   ==============================

startBtn.addEventListener("click", () => {
welcomeScreen.classList.remove("active");
quizScreen.classList.add("active");
loadQuestion();
startTimer();

});

// ==================================== LOAD QUESTION ====================================

function loadQuestion(){
clearInterval(timerInterval);
timeLeft = 20;
startTimer();

questionCount.innerHTML =
`Question ${currentQuestion+1} of ${questions.length}`;

progressBar.style.width =
((currentQuestion+1)/questions.length)*100 + "%";

question.innerHTML =
questions[currentQuestion].question;

options.innerHTML="";
questions[currentQuestion].options.forEach(option=>{

const div=document.createElement("div");

div.classList.add("option");

if(answers[currentQuestion]===option){

div.classList.add("selected");

}

div.innerHTML=`

<input
type="radio"
name="answer"
${answers[currentQuestion]===option?"checked":""}
>

<span>${option}</span>

`;

div.addEventListener("click",()=>{

answers[currentQuestion]=option;

document.querySelectorAll(".option")
.forEach(o=>o.classList.remove("selected"));

div.classList.add("selected");

loadQuestion();

});

options.appendChild(div);

});

prevBtn.disabled=currentQuestion===0;

if(currentQuestion===questions.length-1){

nextBtn.style.display="none";

submitBtn.style.display="block";

}else{

nextBtn.style.display="block";

submitBtn.style.display="none";

}

}

// =================================== TIMER  ==============================

function startTimer(){

timer.innerHTML=timeLeft+"s";

timerInterval=setInterval(()=>{

timeLeft--;

timer.innerHTML=timeLeft+"s";

if(timeLeft<=0){

clearInterval(timerInterval);

if(currentQuestion<questions.length-1){

currentQuestion++;

loadQuestion();

}else{

showResult();

}

}

},1000);

}

// =====================================  NEXT BUTTON  ====================================

nextBtn.addEventListener("click",()=>{

if(currentQuestion<questions.length-1){

currentQuestion++;

loadQuestion();

}

});

// =========================================== PREVIOUS BUTTON ================================

prevBtn.addEventListener("click",()=>{

if(currentQuestion>0){

currentQuestion--;

loadQuestion();

}

});

// ======================================= SUBMIT QUIZ  =======================================

submitBtn.addEventListener("click", showResult);

// ======================================= SHOW RESULT =======================================

function showResult() {

    clearInterval(timerInterval);

    quizScreen.classList.remove("active");
    resultScreen.classList.add("active");

    scoreCount = 0;

    for (let i = 0; i < questions.length; i++) {

        if (answers[i] === questions[i].answer) {
            scoreCount++;
        }

    }

    const wrongCount = questions.length - scoreCount;
    const percent = Math.round((scoreCount / questions.length) * 100);

    score.textContent = `${scoreCount}/${questions.length}`;
    correct.textContent = scoreCount;
    wrong.textContent = wrongCount;
    percentage.textContent = percent + "%";

    // Performance Message

    if (percent >= 90) {

        message.textContent = "🏆 Excellent!";

    } else if (percent >= 75) {

        message.textContent = "🎉 Great Job!";

    } else if (percent >= 50) {

        message.textContent = "👍 Good Effort!";

    } else {

        message.textContent = "📚 Keep Practicing!";

    }

    // High Score

    let high = Number(localStorage.getItem("highScore")) || 0;

    if (percent > high) {

        high = percent;
        localStorage.setItem("highScore", high);

    }

    highScore.textContent = high + "%";

}


// ===================================  RESTART QUIZ ========================================

restartBtn.addEventListener("click", restartQuiz);

function restartQuiz() {

    currentQuestion = 0;
    scoreCount = 0;
    answers = new Array(questions.length).fill(null);
    questions.sort(() => Math.random() - 0.5);

    questions.forEach(q => {
        q.options.sort(() => Math.random() - 0.5);
    });

    clearInterval(timerInterval);

    resultScreen.classList.remove("active");
    quizScreen.classList.remove("active");
    welcomeScreen.classList.add("active");

}


// =================================== OPTIONAL: SHOW CORRECT ANSWER ==============================

function showCorrectAnswer(index) {

    const optionElements = document.querySelectorAll(".option");
    optionElements.forEach((element) => {

        const text = element.querySelector("span").textContent;

        if (text === questions[index].answer) {

            element.classList.add("correct-answer");

        }

        if (
            answers[index] === text &&
            text !== questions[index].answer
        ) {

            element.classList.add("wrong-answer");

        }

    });

}