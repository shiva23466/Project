// Array to store products
let products = [];

// Add Product Function
function addProduct() {

    let productName = document.getElementById("productName").value.trim();
    let price = Number(document.getElementById("price").value);
    let quantity = Number(document.getElementById("quantity").value);

    // Validation
    if (
        productName === "" ||
        price <= 0 ||
        quantity <= 0
    ) {
        alert("Please enter valid details.");
        return;
    }

    // Calculate total
    let total = price * quantity;

    // Product Object
    let product = {
        productName,
        price,
        quantity,
        total
    };

    // Add product to array
    products.push(product);

    // Update UI
    displayProducts();

    // Clear Inputs
    document.getElementById("productName").value = "";
    document.getElementById("price").value = "";
    document.getElementById("quantity").value = "";
}

// Display Products
function displayProducts() {

    let tableBody = document.getElementById("tableBody");

    tableBody.innerHTML = "";

    products.forEach((product, index) => {

        tableBody.innerHTML += `
            <tr>
                <td>${product.productName}</td>
                <td>₹${product.price}</td>
                <td>${product.quantity}</td>
                <td>₹${product.total}</td>
                <td>
                    <button
                        class="delete-btn"
                        onclick="deleteProduct(${index})">
                        Delete
                    </button>
                </td>
            </tr>
        `;
    });

    calculateSummary();
}

// Calculate Bill Summary
function calculateSummary() {

    let totalProducts = products.length;

    let grandTotal = 0;

    for (let i = 0; i < products.length; i++) {
        grandTotal += products[i].total;
    }

    let averageCost =
        totalProducts > 0
        ? grandTotal / totalProducts
        : 0;

    document.getElementById("totalProducts").textContent =
        totalProducts;

    document.getElementById("grandTotal").textContent =
        grandTotal.toFixed(2);

    document.getElementById("averageCost").textContent =
        averageCost.toFixed(2);
}

// Delete Product
function deleteProduct(index) {

    products.splice(index, 1);

    displayProducts();
}