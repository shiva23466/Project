const apiKey = "5e35160a20566d3c1c500d37597ac5f7";
const apiUrl = "https://api.openweathermap.org/data/2.5/weather";

const locationInput = document.getElementById("locationInput");
const searchButton = document.getElementById("searchButton");
const locationName = document.getElementById("location");
const temperature = document.getElementById("temperature");
const description = document.getElementById("description");
const feelsLike = document.getElementById("feelsLike");
const humidity = document.getElementById("humidity");
const wind = document.getElementById("wind");


searchButton.addEventListener("click", function () {
    let city = locationInput.value.trim();
    if (city == "") {
        alert("Please enter a city name.");
    } else {
        getWeather(city);
    }

});

locationInput.addEventListener("keypress", function (event) {
    if (event.key == "Enter") {
        searchButton.click();
    }

});


function getWeather(city) {
    let url = apiUrl + "?q=" + city + "&appid=" + apiKey + "&units=metric";

    fetch(url)
        .then(function (response) {
            return response.json();
        })

        .then(function (data) {
            if (data.cod == "404") {
                alert("City not found!");

                locationName.innerHTML = "Search a City";
                temperature.innerHTML = "--";
                description.innerHTML = "Weather Description";

                feelsLike.innerHTML = "-- °C";
                humidity.innerHTML = "-- %";
                wind.innerHTML = "-- m/s";

                return;

            }
           
            locationName.innerHTML = data.name + ", " + data.sys.country;
            temperature.innerHTML = Math.round(data.main.temp) + "°C";
            description.innerHTML = data.weather[0].description;
            feelsLike.innerHTML = Math.round(data.main.feels_like) + "°C";
            humidity.innerHTML = data.main.humidity + "%";
            wind.innerHTML = data.wind.speed + " m/s";

            let weather = data.weather[0].main;

            if (weather == "Clear") {
                document.body.style.background =
                    "linear-gradient(to right,#f6d365,#fda085)";
            }

            else if (weather == "Clouds") {
                document.body.style.background =
                    "linear-gradient(to right,#757F9A,#D7DDE8)";
            }

            else if (weather == "Rain") {
                document.body.style.background =
                    "linear-gradient(to right,#4B79A1,#283E51)";
            }

            else if (weather == "Snow") {
                document.body.style.background =
                    "linear-gradient(to right,#E6DADA,#274046)";
            }

            else if (weather == "Thunderstorm") {
                document.body.style.background =
                    "linear-gradient(to right,#232526,#414345)";
            }

            else if (weather == "Drizzle") {
                document.body.style.background =
                    "linear-gradient(to right,#89F7FE,#66A6FF)";
            }

            else if (weather == "Mist") {
                document.body.style.background =
                    "linear-gradient(to right,#BDC3C7,#2C3E50)";
            }

            else {
                document.body.style.background =
                    "linear-gradient(to right,#4facfe,#00f2fe)";
            }

        })

        .catch(function () {
            alert("Something went wrong. Please try again.");

        });

}