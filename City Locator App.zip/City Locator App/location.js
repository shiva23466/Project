const apiKey = "0b420a0e60cd4909ef3a850cce463ca4";

const cityInput = document.getElementById("city");
const searchBtn = document.getElementById("searchBtn");
const liveLocationBtn = document.getElementById("liveLocationBtn");
const result = document.getElementById("result");

searchBtn.addEventListener("click", getLocation);

cityInput.addEventListener("keypress", function (e) {
    if (e.key === "Enter") {
        getLocation();
    }
});

liveLocationBtn.addEventListener("click", getLiveLocation);

async function getLocation() {
    const city = cityInput.value.trim();
    if (city === "") {
        result.innerHTML = `<p class="error">Please enter a city name.</p>`;
        return;
    }

    const url = `https://api.openweathermap.org/geo/1.0/direct?q=${encodeURIComponent(city)}&limit=1&appid=${apiKey}`;

    try {
        const response = await fetch(url);
        if (!response.ok) {
            throw new Error(`HTTP Error: ${response.status}`);
        }
        const data = await response.json();

        if (data.length === 0) {
            result.innerHTML = `<p class="error">City not found.</p>`;
            return;
        }

        const location = data[0];
        result.innerHTML = `
            <div class="card">
                <h2>📍 ${location.name}</h2>
                <p><strong>Country:</strong> ${location.country}</p>
                <p><strong>State:</strong> ${location.state || "N/A"}</p>
                <p><strong>Latitude:</strong> ${location.lat}</p>
                <p><strong>Longitude:</strong> ${location.lon}</p>
                <a href="https://www.google.com/maps?q=${location.lat},${location.lon}" target="_blank">
                    🌍 View on Google Maps
                </a>
            </div>
        `;

    } catch (error) {
        console.error(error);
        result.innerHTML = `
            <p class="error">
                Something went wrong.<br>
                ${error.message}
            </p>
        `;
    }
}


function getLiveLocation() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(showPosition, showError);
    } else {
        result.innerHTML = `<p class="error">Geolocation is not supported by this browser.</p>`;
    }
}

function showPosition(position) {
    const latitude = position.coords.latitude;
    const longitude = position.coords.longitude;

    result.innerHTML = `
        <div class="card">
            <h2>📍 Your Live Location</h2>
            <p><strong>Latitude:</strong> ${latitude}</p>
            <p><strong>Longitude:</strong> ${longitude}</p>
            <a href="https://www.google.com/maps?q=${latitude},${longitude}" target="_blank">
                🌍 Open in Google Maps
            </a>
        </div>
    `;
}

function showError(error) {

    switch (error.code) {
        case error.PERMISSION_DENIED:
            result.innerHTML = `<p class="error">Location permission denied.</p>`;
            break;
        case error.POSITION_UNAVAILABLE:
            result.innerHTML = `<p class="error">Location unavailable.</p>`;
            break;
        case error.TIMEOUT:
            result.innerHTML = `<p class="error">Location request timed out.</p>`;
            break;
        default:
            result.innerHTML = `<p class="error">An unknown error occurred.</p>`;
    }
}