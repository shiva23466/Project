// DATA STORAGE

const MENU = {
  Size: {
    thin: 8.00,
    regular: 10.00,
    stuffed: 12.00
  },

  Lenght: {
    small: 1.0,
    medium: 1.5,
    large: 2.0
  },

  toppings: {
    cheese: 1.0,
    pepperoni: 1.0,
    mushrooms: 1.0,
    onions: 1.0,
    peppers: 1.0,
    sausage: 1.0
  }
};


// PURE FUNCTIONS

const calculatePrice = (Size, Lenght) => {
  const Sizeprize =
    MENU.Size[Size] || MENU.Size.regular;

  const Lenghtprize =
    MENU.Lenght[Lenght] || MENU.Lenght.medium;

  return Sizeprize * Lenghtprize;
};


const calculateToppingsPrice = (toppings) => {
  return toppings.reduce((total, topping) => {
    return total + MENU.toppings[topping];
  }, 0);
};


// HIGHER ORDER FUNCTION

const calculateTotalPrice =
(calculatePrice, calculateToppingsPrice) => {

  return (Size, Lenght, toppings) => {

    const basePrice =
      calculatePrice(Size, Lenght);

    const toppingsPrice =
      calculateToppingsPrice(toppings);

    return {
      basePrice,
      toppingsPrice,
      total: basePrice + toppingsPrice
    };
  };
};


const getTotal =
calculateTotalPrice(
  calculatePrice,
  calculateToppingsPrice
);


// DEFAULT SIZE

let selectedLength = "small";


// SIZE BUTTONS

document
.querySelectorAll(".size-btn")
.forEach(button => {

  button.addEventListener("click", () => {

    document
    .querySelectorAll(".size-btn")
    .forEach(btn =>
      btn.classList.remove("active")
    );

    button.classList.add("active");

    selectedLength =
    button.dataset.length;

  });

});


// ORDER BUTTON

document
.getElementById("orderBtn")
.addEventListener("click", () => {

  const size =
  document.getElementById("size").value;

  const toppings =
  [...document.querySelectorAll(
    '.toppings input:checked'
  )]
  .map(item => item.value);

  const result =
  getTotal(
    size,
    selectedLength,
    toppings
  );

  document.getElementById("rCrust")
  .textContent = size;

  document.getElementById("rLength")
  .textContent = selectedLength;

  document.getElementById("rToppings")
  .textContent =
  toppings.length
  ? toppings.join(", ")
  : "None";

  document.getElementById("basePrice")
  .textContent =
  result.basePrice.toFixed(2);

  document.getElementById("topPrice")
  .textContent =
  result.toppingsPrice.toFixed(2);

  document.getElementById("totalPrice")
  .textContent =
  result.total.toFixed(2);

});