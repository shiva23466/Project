import { apiKey } from "./config.js";

const chatBox = document.getElementById("chatBox");
const userInput = document.getElementById("userInput");
const sendBtn = document.getElementById("sendBtn");

function addMessage(text, sender) {
  const msg = document.createElement("div");
  msg.className = `message ${sender}`;
  msg.innerText = text;
  chatBox.appendChild(msg);
  chatBox.scrollTop = chatBox.scrollHeight;
}

function typing() {
  const div = document.createElement("div");
  div.className = "typing";
  div.innerText = "🤖 AI is typing...";
  chatBox.appendChild(div);
  chatBox.scrollTop = chatBox.scrollHeight;
  return div;
}

async function getReply(message) {
  const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${apiKey}`;
  try {
    const response = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },

      body: JSON.stringify({
        contents: [
          {
            parts: [
              {
                text: message,
              },
            ],
          },
        ],
      }),
    });

    const data = await response.json();

    return data.candidates[0].content.parts[0].text;
  } catch (error) {
    return "❌ Something went wrong.";
  }
}

sendBtn.onclick = async () => {
  const message = userInput.value.trim();
  if (message === "") return;
  addMessage(message, "user");
  userInput.value = "";
  const loading = typing();
  const reply = await getReply(message);
  loading.remove();
  addMessage(reply, "bot");
};

userInput.addEventListener("keypress", (e) => {
  if (e.key === "Enter") {
    sendBtn.click();
  }
});
